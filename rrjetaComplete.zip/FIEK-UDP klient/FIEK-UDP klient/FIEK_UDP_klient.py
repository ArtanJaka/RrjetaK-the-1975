from socket import *

from sys import exit

port=12002
portS=9000
Ip="localhost"

ClientSocket = socket(AF_INET, SOCK_DGRAM)
ClientSocket.bind(('', port))
ClientSocket.settimeout(5.0)

print("-------------Klienti FIEK-UDP--------------")


def ip():
    message = "IP "
    message = message.encode("UTF-8")
    ClientSocket.sendto(message,(Ip,portS)) 
    try:
        response,addr = ClientSocket.recvfrom(1024)
        response = response.decode("UTF-8")
        print (response)
    except:
        print ("Error: Serveri nuk ka kthyer pergjigje")
    menu()
def port():
    message = "PORT "
    message = message.encode("UTF-8")
    ClientSocket.sendto(message,(Ip,portS)) 
    try:
        response,addr = ClientSocket.recvfrom(1024)
        response = response.decode("UTF-8")
        print (response)
    except:
        print ("Error: Serveri nuk ka kthyer pergjigje")
    menu()
def zanore():
    message = "ZANORE "    
    message=message+str(input("Jep nje fjali:"))
    message = message.encode("UTF-8")
    ClientSocket.sendto(message,(Ip,portS)) 
    try:
        response,addr = ClientSocket.recvfrom(1024)
        response = response.decode("UTF-8")
        print (response)
    except:
        print ("Error: Serveri nu ka kthyer pergjigje")
    menu()
def printo():
    message = "PRINTO "
    message = message+str(input("Mezashi: "))
    message = message.encode("UTF-8")
    ClientSocket.sendto(message,(Ip,portS)) 
    try:
        response,addr = ClientSocket.recvfrom(1024)
        response = response.decode("UTF-8")
        print (response)
    except:
        print ("Error: Serveri nu ka kthyer pergjigje")
    menu()
def host():
    message = "HOST "
    message = message.encode("UTF-8")
    ClientSocket.sendto(message,(Ip,portS)) 
    try:
        response,addr = ClientSocket.recvfrom(1024)
        response = response.decode("UTF-8")
        print (response)
    except:
        print ("Error: Serveri nuk ka kthyer pergjigje")
    menu()
def time():
    message = "TIME "
    message = message.encode("UTF-8")
    ClientSocket.sendto(message,(Ip,portS)) 
    try:
        response,addr = ClientSocket.recvfrom(1024)
        response = response.decode("UTF-8")
        print (response)
    except:
        print ("Error: Serveri nu ka kthyer pergjigje")
    menu()
def keno():
    message = "KENO "
    message = message.encode("UTF-8")
    ClientSocket.sendto(message,(Ip,portS)) 
    try:
        response,addr = ClientSocket.recvfrom(1024)
        response = response.decode("UTF-8")
        print (response)
    except:
        print ("Error: Serveri nu ka kthyer pergjigje")
    menu()
def faktoriel():
    message = "FAKTORIEL "
    fakt = str(input('Kerko faktorielin e numrit: '))
    message = message+fakt
    message = message.encode("UTF-8")
    ClientSocket.sendto(message,(Ip,portS)) 
    try:
        response,addr = ClientSocket.recvfrom(1024)
        response = response.decode("UTF-8")
        print (response)
    except:
        print ("Error: Serveri nu ka kthyer pergjigje")
    menu()    
def konverto():
    message = "KONVERTO "
    print("\n----------------------")
    print("1.Celcius To Kelvin")
    print("2.Celsius To Fahrenheit")
    print("3.Kelvin To Fahrenheit")
    print("4.Kelvin To Celsius")
    print("5.Fahrenheit To Celsius")
    print("6.Fahrenheit To Kelvin")
    print("7.Pound To Kilogram")
    print("8.Kilogram To Pound")
    option = str(input("Zgjedh opsionin: "))
    if(option=="1"):  
        message = message+"CelciusToKelvin "
    if(option=="2"):
        message = message+"CelsiusToFahrenheit "
    if(option=="3"):
        message = message+"KelvinToFahrenheit "
    if(option=="4"):
        message = message+"KelvinToCelsius "
    if(option=="5"):
        message = message+"FahrenheitToCelsius "
    if(option=="6"):
        message = message+"FahrenheitToKelvin "
    if(option=="7"):
        message = message+"PoundToKilogram " 
    if(option=="8"):
        message = message+"KilogramToPound "
    message = message+input("Sasia: ")
    message = message.encode("UTF-8")
    ClientSocket.sendto(message,(Ip,portS)) 
    try:
        response,addr = ClientSocket.recvfrom(1024)
        response = response.decode("UTF-8")
        print (response)
    except:
        print ("Error: Serveri nu ka kthyer pergjigje")
    menu()
def M1():
    message = "M1 "
    message = message+str(input("Fjalia per tu Koduar: "))
    message = message.encode("UTF-8")
    ClientSocket.sendto(message,(Ip,portS)) 
    try:
        response,addr = ClientSocket.recvfrom(1024)
        response = response.decode("UTF-8")
        print (response)
    except:
        print ("Error: Serveri nu ka kthyer pergjigje")
    menu()
def M2():
    message = "M2 "
    message = message+str(input("Numri i rreshtave h= "))
    message = message+" "+str(input("Numri i Shtyllave w= "))
    message = message+" "+str(input("Vlerat : "))
    message = message.encode("UTF-8")
    ClientSocket.sendto(message,(Ip,portS)) 
    try:
        response,addr = ClientSocket.recvfrom(1024)
        response = response.decode("UTF-8")
        print (response)
    except:
        print ("Error: Serveri nu ka kthyer pergjigje")
    menu()
def M3():
    message = "M3 "
    message=message+str(input("Shkruani tekstin:"))
    message = message.encode("UTF-8")
    ClientSocket.sendto(message,(Ip,portS)) 
    try:
        response,addr = ClientSocket.recvfrom(1024)
        response = response.decode("UTF-8")
        print (response)
    except:
        print ("Error: Serveri nu ka kthyer pergjigje")
    menu()
def M4():
    message = "M4 "
    message=message+str(input("Jepni numrat(x y z ...):"))
    message = message.encode("UTF-8")
    ClientSocket.sendto(message,(Ip,portS)) 
    try:
        response,addr = ClientSocket.recvfrom(1024)
        response = response.decode("UTF-8")
        print (response)
    except:
        print ("Error: Serveri nu ka kthyer pergjigje")
    menu()
def M5():
    message = "M5 "
    message = message.encode("UTF-8")
    ClientSocket.sendto(message,(Ip,portS)) 
    try:
        response,addr = ClientSocket.recvfrom(1024)
        response = response.decode("UTF-8")
        print (response)
    except:
        print ("Error: Serveri nu ka kthyer pergjigje")
    menu()
def M6():
    message = "M6 "
    message = message.encode("UTF-8")
    ClientSocket.sendto(message,(Ip,portS)) 
    try:
        response,addr = ClientSocket.recvfrom(1024)
        response = response.decode("UTF-8")
        print (response)
    except:
        print ("Error: Serveri nu ka kthyer pergjigje")
    menu()
def M7():
    message = "M7 "
    message = message.encode("UTF-8")
    ClientSocket.sendto(message,(Ip,portS)) 
    try:
        response,addr = ClientSocket.recvfrom(1024)
        response = response.decode("UTF-8")
        print (response)
    except:
        print ("Error: Serveri nu ka kthyer pergjigje")
    menu()
def M8():
    message = "M8 "
    message = message.encode("UTF-8")
    ClientSocket.sendto(message,(Ip,portS)) 
    try:
        response,addr = ClientSocket.recvfrom(1024)
        response = response.decode("UTF-8")
        print (response)
    except:
        print ("Error: Serveri nu ka kthyer pergjigje")
    menu()
def end():
    ClientSocket.close()
    exit();
def freestyle():
    message = str(input("Request: "))
    message = message.encode("UTF-8")
    ClientSocket.sendto(message,(Ip,portS)) 
    try:
        response,addr = ClientSocket.recvfrom(1024)
        response = response.decode("UTF-8")
        print (response)
    except:
        print ("Error: Serveri nu ka kthyer pergjigje")
    menu()

def menu():
    print (" ")
    print("---------------------------")
    print("1.OPTIONS")
    print("2.EXIT")
    option = '1'
    option = str(input("opsioni:"))
    if(option == '1'):
        print (" ")
        print("-------------Options--------------")
        print("1.IP")
        print("2.PORT")
        print("3.ZANORE")
        print("4.PRINTO")
        print("5.HOST")
        print("6.TIME")
        print("7.KENO")
        print("8.FAKTORIEL")
        print("9.KONVERTO")
        print("10.FREESTYLE")
        print("11.INDIVIDUALE")
        print("12.EXIT")    
        option = str(input('Zgjedh opt Numer: '))
    
        if(option == '1'):
            ip()
        if(option == '2'):
            port()
        if(option == '3'):
            zanore()
        if(option == '4'):
            printo()
        if(option == '5'):
            host()
        if(option == '6'):
            time()
        if(option == '7'):
            keno()
        if(option == '8'):
            faktoriel()
        if(option == '9'):
            konverto()
        if(option == '10'):
            freestyle()
        if(option == '11'):
            print("--------------------")
            print("1.Artan - M1 - PiktoKod")
            print("2.Artan - M2 - MatricaPattern")
            print("3.Argjent - M1 - Invers")
            print("4.Argjent - M2 - NrMax")
            print("5.Adriatik - M1")
            print("6.Adriatik - M2")
            print("7.Kaltrina - M1")
            print("8.Kaltrina - M2")
            option = str(input('Zgjedh opt Numer: '))
            if(option == '1'):
                M1()
            if(option == '2'):
                M2()
            if(option == '3'):
                M3()
            if(option == '4'):
                M4()
            if(option == '5'):
                M5()
            if(option == '6'):
                M6()
            if(option == '7'):
                M7()
            if(option == '8'):
                M8()
            print ("Keni shtypur opsion jovalid")
            menu()
        if(option == '12'):
            end()    
        print ("Keni shtypur opsion jovalid")
        menu()        
    if(option == '2'):
        end()
    print ("Keni shtypur opsion jovalid")
    menu()

menu()
